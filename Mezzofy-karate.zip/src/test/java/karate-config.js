function fn() {
 
  var env = karate.env; // get system property 'karate.env'
  karate.log('karate.env system property was:', env);
  
  if (!env) {
    env = 'dev';
  }
  var config = {
    env: env,
    myVarName: 'someValue',
    NFC_V3_Api: 'https://dvbusiness.mzpv3001.mezzofy.com/v3/integration',
    NFC_Purchase_Api:"https://express.mzapi.mezzofy.com/v2/nfccoupondistribute",
    username: 'By3I7fX',
    password: 'platform',
    Customer_Detail_API:'https://customer.mzapi.mezzofy.com/v2/profile/detail',
    baseUrl:"https://dvbusiness.mzpv3001.mezzofy.com/v3/master",
    InvalidUrl:"https://dvbusiness.mzpv3001.mezzofy.com/v2/master",
    NFC_Purchase_detailApi :"https://express.mzapiea.mezzofy.com/v2/nfccoupondistribute/{{nfc_txn_id}}?lang=en"
  }

  if (env == 'dev') {
    // customize
    // e.g. config.foo = 'bar';
  } else if (env == 'e2e') {
    // customize
  }
  return config;
}