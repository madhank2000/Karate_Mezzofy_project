package examples;

import com.intuit.karate.Results;
import com.intuit.karate.Runner;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

class ExamplesTest {
    private static final Logger logger = LoggerFactory.getLogger(ExamplesTest.class);

    @Test
    void testParallel() {
    
        int threadCount = 5; // Set the desired thread count here
        System.out.println("Running tests with " + threadCount + " threads");
        logger.info("Running tests with {} threads#####", threadCount);
        int activeThreads = Thread.activeCount();
        System.out.println(" - Active Threads:@@@ " + activeThreads);
        Results results = Runner.path(
                // "/home/madhanagopal/Videos/Mezzofy-karate/src/test/java/examples/Mezzofy API/V2 API/NFcPurchaseAPI.feature",
                // "/home/madhanagopal/Videos/Mezzofy-karate/src/test/java/examples/Mezzofy API/V3 API/NFCDetailAPI.feature"
                // "/home/madhanagopal/Videos/Mezzofy-karate/src/test/java/examples/Mezzofy_API/V3_API/Merchants Module/MerchantAuthAPI copy.feature"
                // "/home/madhanagopal/Videos/Mezzofy-karate/src/test/java/examples/Mezzofy_API/V2_API/NFcPurchaseAPI.feature"
                "/home/madhanagopal/Videos/Mezzofy-karate/src/test/java/examples/Mezzofy_API/V2_API/SerialListAPI.feature"
                // "/home/madhanagopal/Videos/Mezzofy-karate/src/test/java/examples/Mezzofy_API/V3_API/Merchants Module/MerchantDetailAPI.feature"
                )
                .outputCucumberJson(true)
                .parallel(threadCount);

        logger.info("Parallel execution completed. Total scenarios: {}, Passed: {}, Failed: {} , getFeaturesTotal{}",
                results.getFeaturesTotal(), results.getScenariosPassed(), results.getFailCount(),
                results.getFeatureResults());

        assertEquals(0, results.getFailCount(), results.getErrorMessages());
    }

}


